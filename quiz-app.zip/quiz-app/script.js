const questionText = document.getElementById("question-text");
const optionsContainer = document.getElementById("options");
const nextButton = document.getElementById("next-button");
const resultContainer = document.getElementById("result");
const progressBar = document.getElementById("progress-bar");

let currentQuestionIndex = 0;
let score = 0;

// Load questions from the JSON file
fetch("questions.json")
  .then((response) => response.json())
  .then((data) => {
    const questions = data;
    const totalQuestions = questions.length; // Calculate the total number of questions

    // Shuffle the questions to randomize their order
    shuffleArray(questions);

    // Initialize the quiz
    loadQuestion(questions[currentQuestionIndex]);

    nextButton.addEventListener("click", () => {
        const selectedOption = document.querySelector("input[type=radio]:checked");
        if (!selectedOption) return;
    
        const currentQuestion = questions[currentQuestionIndex];
        const selectedAnswer = selectedOption.value;
        
        // Highlight the correct option in green
        const correctOption = Array.from(optionsContainer.getElementsByTagName("label")).find(
            (label) => label.textContent.trim() === currentQuestion.options.find((option) => option.isCorrect).text
        );
        if (correctOption) {
            correctOption.classList.add("correct");
        }
        
        // Highlight incorrect options in red
        Array.from(optionsContainer.getElementsByTagName("label")).forEach((label) => {
            if (label !== correctOption && label.querySelector("input").checked) {
                label.classList.add("incorrect");
            }
        });
    
        nextButton.disabled = true; // Disable the "Next" button temporarily
    
        setTimeout(() => {
            // Reset option highlighting and enable the "Next" button
            Array.from(optionsContainer.getElementsByTagName("label")).forEach((label) => {
                label.classList.remove("correct", "incorrect");
            });
            nextButton.disabled = false;
    
            if (selectedAnswer === currentQuestion.options.find((option) => option.isCorrect).text) {
                score++;
            }
    
            currentQuestionIndex++;
    
            if (currentQuestionIndex < totalQuestions) {
                loadQuestion(questions[currentQuestionIndex]);
                selectedOption.checked = false;
                
                // Calculate the progress dynamically
                const progress = (currentQuestionIndex / totalQuestions) * 100;
                progressBar.style.width = `${progress}%`;
            } else {
                showResult();
            }
        }, 1000); // Delay the transition to the next question
    });
    
  })
  .catch((error) => console.error(error));

function loadQuestion(question) {
  questionText.textContent = question.question;
  optionsContainer.innerHTML = "";

  // Shuffle the options to randomize their order
  const shuffledOptions = [...question.options];
  shuffleArray(shuffledOptions);

  shuffledOptions.forEach((option, index) => {
    const label = document.createElement("label");
    label.innerHTML = `
      <input type="radio" name="option" value="${option.text}" />
      ${option.text}
    `;
    optionsContainer.appendChild(label);
  });
}

function showResult() {
  questionText.textContent = "";
  optionsContainer.innerHTML = "";
  nextButton.style.display = "none";
  progressBar.style.width = "100%";

  resultContainer.textContent = `You scored ${score} out of ${currentQuestionIndex}!`;
}

function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}

